import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from fastapi import FastAPI
from fastapi.testclient import TestClient
import v2_api
import v2_radio

class TimerAPITests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.state=Path(self.temp.name)
  (self.state/'credentials.json').write_text(json.dumps({'username':'admin','salt':'11'*32,'hash':'unused'}))
  app=FastAPI();v2_api.install_routes(app,self.state,self.state)
  self.client=TestClient(app)
  auth=patch('accounts.require',return_value={'username':'admin'});auth.start();self.addCleanup(auth.stop)
 def test_global_off_and_minutes_persist(self):
  for body in ({'enabled':False,'minutes':10},{'enabled':True,'minutes':27}):
   response=self.client.post('/api/dynamic-timer',json=body)
   self.assertEqual(response.status_code,200)
   saved=json.loads((self.state/'dynamic-timer.json').read_text())
   self.assertEqual(saved['enabled'],body['enabled']);self.assertEqual(saved['minutes'],body['minutes'])
   self.assertEqual(self.client.get('/api/dynamic-timer').json()['enabled'],body['enabled'])
 def test_unsupported_mode_rejected(self):
  for mode,family in (('allstar','AllStar'),('p25','P25'),('dmr','CBridge')):
   self.assertEqual(self.client.post('/api/gateway-policy',json={'mode':mode,'family':family,'destination':'91'}).status_code,400)
 def test_invalid_minutes_rejected(self):
  for minutes in (0,1441,True,'10'):
   self.assertEqual(self.client.post('/api/dynamic-timer',json={'minutes':minutes}).status_code,422)
 def test_native_timer_requires_current_rf_source(self):
  body={'mode':'ysf','family':'FCS','destination':'FCS00334','enabled':True,'minutes':10}
  self.assertEqual(self.client.post('/api/gateway-policy',json=body).status_code,400)
 @unittest.skipUnless(importlib.util.find_spec('fcntl'),'Per-room writes require Linux file locking')
 def test_room_and_bm_slot_settings_roundtrip(self):
  for body,key in (({'mode':'dmr2ysf','family':'FCS','destination':'FCS00334','slot':2,'enabled':False,'minutes':25},'2|FCS|FCS00334'),({'mode':'dmr','family':'BrandMeister','destination':'*','slot':1,'enabled':True,'minutes':7},'1|BrandMeister|*')):
   self.assertEqual(self.client.post('/api/gateway-policy',json=body).status_code,200)
   saved=self.client.get('/api/gateway-policy').json()[key]
   self.assertEqual(saved['enabled'],body['enabled']);self.assertEqual(saved['minutes'],body['minutes'])

class QueuedTimerTests(unittest.TestCase):
 def test_off_static_or_changed_policy_cancels_queued_request(self):
  job={'mode':'dmr2ysf','operation':'unlink','slot':2,'family':'FCS','destination':'FCS00334','username':'auto-timeout','created':100}
  for global_policy,local_policy in (({'enabled':False},{}),({'updated':101},{}),({}, {'static':True}),({}, {'enabled':False}),({}, {'updated':101})):
   def read(path,*args,**kwargs):
    return json.dumps(global_policy if path.name=='dynamic-timer.json' else {'2|FCS|FCS00334':local_policy})
   with patch('v2_radio.validate'),patch.object(Path,'exists',return_value=True),patch.object(Path,'read_text',read),patch('v2_radio.mqtt_exchange') as mqtt:
    self.assertIn('cancelled',v2_radio.execute(job));mqtt.assert_not_called()
