'use strict';
let lastLinks='';
async function refreshLinks(){
 try{
  const [r,policies]=await Promise.all([api('links'),api('gateway-policy').catch(()=>null)]);const signed=!!(csrf&&window.v2Identity);const signature=JSON.stringify([r.slots,signed,policies]);if(signature===lastLinks)return;lastLinks=signature;
  $('linked-slots').replaceChildren(...r.slots.map(slot=>{
   const box=node('section');box.append(node('h4',slot.label||'TS'+slot.slot));
   for(const link of slot.links){const row=node('div',undefined,'linked-row');const label=(link.mode==='dmr2ysf'?'DMR2YSF → ':link.mode==='ysf'?'Fusion → ':'')+(link.family==='BrandMeister'?'TG ':'')+(link.destination||link.family)+(link.name==='TG '+link.destination?'':' · '+link.name)+(link.kind&&link.kind!=='gateway'?' ('+link.kind+')':'');
    const choice=node(signed&&link.destination?'button':'div',label,'linked-choice');
    if(signed&&link.destination){choice.title='Load into Radio Control';choice.onclick=async()=>{await loadControls();document.querySelector('[data-view="overview"]').click();$('rc-mode').value=link.mode;updateMode();if(link.mode!=='ysf')$('rc-slot').value=String(slot.slot);$('rc-family').value=link.family;$('rc-search').value='';await destinations();$('rc-destination').value=link.destination;$('radio-controls').scrollIntoView({behavior:'smooth',block:'nearest'});};}
    row.append(choice);
    if(link.kind==='gateway'){
     const key=[slot.slot||2,link.family,link.destination].join('|');const isStatic=!!policies?.[key]?.static;
     row.append(node('span',policies===null?'Policy unavailable':isStatic?'Static':'Dynamic','linked-note'));
     if(signed&&policies!==null){const toggle=node('button',isStatic?'Make dynamic':'Make static','linked-unlink');toggle.onclick=async()=>{toggle.disabled=true;try{const result=await api('gateway-policy',{method:'POST',body:JSON.stringify({mode:link.mode,slot:slot.slot||2,family:link.family,destination:link.destination,static:!isStatic})});fill('linked-feedback',result.message);lastLinks='';await refreshLinks();}catch(e){fill('linked-feedback',e.message);}finally{toggle.disabled=false;}};row.append(toggle);}
    }
    if(signed&&link.unlink){const unlink=node('button','Unlink','linked-unlink');unlink.onclick=async()=>{if(!confirm('Unlink '+(link.destination||link.name)+(link.family==='BrandMeister'?'? This removes the static BrandMeister subscription.':'? This sends a native disconnect command to the shared YSF gateway.')))return;unlink.disabled=true;try{const result=await api('radio-control',{method:'POST',body:JSON.stringify({mode:link.mode,slot:link.mode==='ysf'?2:slot.slot,operation:'unlink',family:link.family,destination:link.destination,subscription_kind:link.kind||'static'})});fill('linked-feedback',result.message);}catch(e){fill('linked-feedback',e.message);}finally{unlink.disabled=false;}};row.append(unlink);}
    if(signed&&policies!==null&&link.kind==='gateway'&&(link.mode==='dmr2ysf'||(link.mode==='ysf'&&link.timer_supported))&&['YSF','FCS'].includes(link.family))row.append(linkTimerControl(link,slot,policies));
    box.append(row);
   }
   if(signed&&slot.clear_dynamic){const clear=node('button','Clear dynamic TGs on TS'+slot.slot,'linked-unlink');clear.onclick=async()=>{if(!confirm('Clear ALL dynamic talkgroups on TS'+slot.slot+'? Static talkgroups are unchanged.'))return;clear.disabled=true;try{const result=await api('radio-control',{method:'POST',body:JSON.stringify({mode:'dmr',slot:slot.slot,operation:'clear_dynamic',family:'BrandMeister',destination:''})});fill('linked-feedback',result.message);}catch(e){fill('linked-feedback',e.message);}finally{clear.disabled=false;}};box.append(clear);}
   if(signed&&policies!==null&&slot.clear_dynamic)box.append(linkTimerControl({mode:'dmr',family:'BrandMeister',destination:'*'},slot,policies));
   box.append(node('p',slot.note,'linked-note'));return box;
  }));
 }catch(e){lastLinks='';$('linked-slots').replaceChildren(...[1,2].map(n=>{const s=node('section');s.append(node('h4','TS'+n),node('p','Link status unavailable.','linked-note'));return s;}));}
}
$('linked-sidebar').append(node('p','','linked-note'));$('linked-sidebar').lastChild.id='linked-feedback';
refreshLinks();setInterval(refreshLinks,3000);


function linkTimerControl(link,slot,policies){
 const wrap=node('details'),summary=node('summary',link.family==='BrandMeister'?'Dynamic TG timer (whole slot)':'Auto-disconnect');wrap.append(summary);
 const policy=policies[[slot.slot||2,link.family,link.destination].join('|')]||{};
 const form=node('form'),enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=policy.enabled!==false&&!policy.static;
 const label=node('label',' Enable auto-disconnect');label.prepend(enabled);form.append(label);
 const input=document.createElement('input');input.type='number';input.min='1';input.max='1440';input.step='1';input.value=policy.minutes||'';input.placeholder='Use global default';input.setAttribute('aria-label','RF inactivity minutes');form.append(input);
 const save=node('button','Save timer');save.type='submit';form.append(save);
 form.append(node('p','Minutes without local RF. Global timer must also be enabled. Static links are exempt.','caption'));
 form.onsubmit=async e=>{e.preventDefault();save.disabled=true;try{const result=await api('gateway-policy',{method:'POST',body:JSON.stringify({mode:link.mode,family:link.family,destination:link.destination,slot:slot.slot||2,static:!!policy.static,enabled:enabled.checked,minutes:input.value?Number(input.value):null})});fill('linked-feedback','Timer saved. '+result.message);lastLinks='';await refreshLinks();}catch(err){fill('linked-feedback',err.message);}finally{save.disabled=false;}};
 wrap.append(form);return wrap;
}
