"""Fixed-origin release checks and dashboard-only updates. No radio operations."""
import os,json,re,time,hashlib,subprocess,tempfile,stat,fcntl
from pathlib import Path
from urllib.request import urlopen,Request
ROOT=Path('/var/lib/mmod-updates');STATE=Path('/var/lib/mmod/state')
ORIGIN='https://raw.githubusercontent.com/txlinked/mmod/'
def version(v):
    if not re.fullmatch(r'\d+\.\d+\.\d+',str(v)):raise ValueError('Invalid release version')
    return tuple(map(int,v.split('.')))
def read(p):
    try:
        fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        with os.fdopen(fd) as f:
            s=os.fstat(f.fileno())
            if not stat.S_ISREG(s.st_mode) or s.st_size>16384:raise ValueError('Invalid update state')
            return json.load(f)
    except FileNotFoundError:return {}
def fetch(url,limit):
    with urlopen(Request(url,headers={'User-Agent':'MMOD-updater'}),timeout=30) as r:
        if not r.url.startswith(ORIGIN):raise ValueError('Unexpected download origin')
        data=r.read(limit+1)
        if len(data)>limit:raise ValueError('Download too large')
        return data
def release():
    d=json.loads(fetch(ORIGIN+'main/stable.json',16384));version(d['version'])
    if not re.fullmatch('[a-f0-9]{40}',d.get('commit','')) or not re.fullmatch('[a-f0-9]{64}',d.get('updater_sha256','')):raise ValueError('Invalid stable release manifest')
    return {k:d[k] for k in ('version','commit','updater_sha256')}
def save(d):
    p=ROOT/'status.new';p.write_text(json.dumps(d));p.chmod(0o644);p.replace(ROOT/'status.json')
def perform(d):
    b=fetch(ORIGIN+d['commit']+'/mmodupdate.sh',1000000)
    if hashlib.sha256(b).hexdigest()!=d['updater_sha256']:raise ValueError('Updater checksum mismatch')
    with tempfile.TemporaryDirectory(prefix='mmod-web-update-') as folder:
        path=Path(folder)/'update.sh';path.write_bytes(b)
        env=dict(os.environ,MMOD_RELEASE=d['commit'])
        # Existing updater owns backup, locking, state preservation and rollback.
        with (ROOT/'last-update.log').open('w') as log:
            os.chmod(ROOT/'last-update.log',0o600)
            result=subprocess.run(['/bin/bash',str(path)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
        if result.returncode:raise ValueError('Update failed; inspect the root-only update log and rollback result.')
    if Path('/opt/mmod/VERSION').read_text().strip()!=d['version']:raise ValueError('Installed version does not match release')
def main():
    ROOT.mkdir(mode=0o755,exist_ok=True);ROOT.chmod(0o755)
    with (ROOT/'worker.lock').open('w') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return
        d=read(ROOT/'status.json');now=time.time()
        try:
            request=read(STATE/'updates-request.json');(STATE/'updates-request.json').unlink(missing_ok=True)
            action=request.get('action') if 0<=now-request.get('created',0)<300 else None
            policy=read(STATE/'updates-settings.json');schedule=policy.get('schedule','03:00')
            if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',str(schedule)):schedule='03:00'
            today=time.strftime('%Y-%m-%d');scheduled=policy.get('enabled') is True and time.strftime('%H:%M')>=schedule and d.get('auto_day')!=today
            if action or scheduled or now-d.get('checked',0)>=86400:
                d.update(release());d.update(checked=now,error=None,message='GitHub stable release checked.')
            if scheduled:d['auto_day']=today
            installed=Path('/opt/mmod/VERSION').read_text().strip();d['available']=bool(d.get('version') and version(d['version'])>version(installed))
            if d['available'] and (action=='install' or scheduled):
                d.update(running=True,message='Updating dashboard; the page will reconnect.');save(d)
                perform(d);d.update(available=False,message='Dashboard updated successfully.',completed=time.time())
            d['running']=False;save(d)
        except Exception as e:
            d.update(running=False,error=str(e)[:250],message='Update/check failed. No automatic retry until the next scheduled day.' if locals().get('scheduled') else 'Update/check failed.')
            if locals().get('scheduled'):d['auto_day']=time.strftime('%Y-%m-%d')
            d['checked']=now;save(d)
if __name__=='__main__':main()
