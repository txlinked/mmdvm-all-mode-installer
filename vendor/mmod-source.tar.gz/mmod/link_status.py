"""Read-only confirmed gateway links; never infer from last-heard traffic."""
import json,re,subprocess,time
from pathlib import Path

def parse(lines):
    result=None
    for line in lines:
        m=re.search(r"Linked to (.+)$",line)
        if m:
            name=m[1].strip()
            f=re.fullmatch(r"FCS(\d{3})-(\d{2})",name)
            result={'family':'FCS' if f else 'YSF','destination':'FCS'+f[1]+f[2] if f else '', 'name':name}
        elif any(x in line for x in ['Link has failed','Disconnect by remote','Disconnecting due','Disconnect has been requested','Disconnect via DTMF','No connection startup','Closing YSF network','Closing FCS network','Connect by remote command','Automatic (re-)connection','(re-)connection to']):
            result=None
    return result

def run(*args):
    return subprocess.check_output(args,text=True,timeout=8).strip()


def configured_dmr_routes(profile):
    """Expose explicit non-BM RF routes without claiming remote subscriptions."""
    import configparser
    config=configparser.ConfigParser(interpolation=None,strict=False)
    try:config.read(profile.get('dmr',{}).get('ini',''))
    except (OSError,configparser.Error):return []
    routes=[]
    bm_net=str(profile.get('bm_net',''))
    for section in config.sections():
        match=re.fullmatch(r'DMR Network (\d+)',section)
        if not match or 'net'+match[1]==bm_net:continue
        values=config[section]
        if values.get('Enabled','0').strip()!='1':continue
        name=values.get('Name',section).strip()
        if name.upper()=='RACKNERD':name='C-Bridge'
        for key,value in values.items():
            if not re.fullmatch(r'tgrewrite\d*',key):continue
            try:rf_slot,rf_tg,net_slot,net_tg,count=map(int,value.split('#',1)[0].split(';',1)[0].split(','))
            except ValueError:continue
            if rf_slot not in (1,2) or count!=1:continue
            route={'slot':rf_slot,'mode':'dmr','family':name,'destination':'',
                   'name':'TG '+str(rf_tg)+' → network TS'+str(net_slot)+'/TG '+str(net_tg),
                   'kind':'configured route','unlink':False}
            if route not in routes:routes.append(route)
    return routes

def main():
    import brandmeister as bm
    p=bm.profile()
    slots=[{'slot':n,'links':[],'note':'No confirmed links.'} for n in (1,2)]
    try:directories=json.loads(Path('/var/lib/mmod/directories.json').read_text()).get('lists',{})
    except (OSError,ValueError):directories={}
    if p.get('bm_id'):
        cache=Path('/run/mmod/bm-subscriptions.json')
        try:data=json.loads(cache.read_text())
        except (OSError,ValueError):data={}
        if data.get('device')!=p['bm_id'] or time.time()-data.get('updated',0)>30:
            try:data={'device':p['bm_id'],'updated':time.time(),'rows':bm.subscriptions(bm.request(p['bm_id'],'/profile'))}
            except ValueError:data={'device':p['bm_id'],'updated':time.time(),'error':True,'rows':[]}
            cache.write_text(json.dumps(data));cache.chmod(0o644)
        key=bm.credentials();can_unlink=bool(key.get('key') and key.get('device')==p['bm_id'] and p.get('duplex'))
        for slot in slots:slot['note']='BrandMeister status unavailable.' if data.get('error') else 'Confirmed BrandMeister subscriptions.'
        for group in slots:group['clear_dynamic']=can_unlink and any(r['kind']=='dynamic' and r['slot']==group['slot'] for r in data.get('rows',[]))
        for row in data.get('rows',[]):
            # BrandMeister simplex slot 0 is displayed on RF TS2.
            slot=row['slot'] or 2
            name=directories.get('BrandMeister',{}).get('entries',{}).get(row['tg'],'TG '+row['tg'])
            slots[slot-1]['links'].append(dict(mode='dmr',family='BrandMeister',slot=slot,destination=row['tg'],name=name,kind=row['kind'],unlink=can_unlink and row['kind']=='static' and row['slot'] in (1,2)))
    else:slots[0]['note']='BrandMeister device not detected.'
    for route in configured_dmr_routes(p):
        group=slots[route['slot']-1]
        group['links'].append(route)
        group['note']='Configured DMRGateway route. Remote subscriptions and link status are not reported by this network.'
    if p.get('ysf') and p.get('ysf_route') in ('native','crossmode'):
        slot=p.get('ysf_slot',2) if p['ysf_route']=='crossmode' else None
        if slot is None:
            group={'slot':None,'label':'Fusion','links':[],'note':'No confirmed Fusion link.'}
            slots.append(group)
        else:group=slots[slot-1]
        try:
            invocation=run('systemctl','show','ysfgateway','-p','InvocationID','--value')
            if not re.fullmatch(r'[a-f0-9]{32}',invocation) or run('systemctl','is-active','ysfgateway')!='active':raise ValueError('Gateway unavailable')
            link=parse(run('journalctl','_SYSTEMD_INVOCATION_ID='+invocation,'-n','2000','--no-pager','-o','cat').splitlines())
            if link:
                entries=directories.get(link['family'],{}).get('entries',{})
                if link['destination']:link['name']=entries.get(link['destination'],link['name']).split(' · ')[0]
                else:
                    matches=[k for k,v in entries.items() if link['name'].strip() in [s.strip() for s in v.split(' · ')]]
                    if len(matches)==1:link['destination']=matches[0]
                link.update(mode='dmr2ysf' if p['ysf_route']=='crossmode' else 'ysf',slot=slot,unlink=True,kind='gateway')
                group['links'].append(link);group['note']='Confirmed network links.'
        except Exception:
            if not group['links']:group['note']='Gateway link status unavailable.'
    out=Path('/run/mmod/links.json');tmp=out.with_suffix('.new')
    tmp.write_text(json.dumps({'updated':time.time(),'slots':slots}));tmp.chmod(0o644);tmp.replace(out)

def prepare_access():
    """Expose only the discovered gateway INI through the status sandbox."""
    import brandmeister
    path=Path(brandmeister.profile().get('dmr',{}).get('ini',''))
    drop=Path('/etc/systemd/system/mmod-links.service.d/config-read.conf')
    if path.is_file() and str(path).startswith('/home/') and re.fullmatch(r'/[A-Za-z0-9_./-]+',str(path)):
        drop.parent.mkdir(parents=True,exist_ok=True)
        drop.write_text('[Service]\nProtectHome=tmpfs\nBindReadOnlyPaths='+str(path)+'\n')
    else:drop.unlink(missing_ok=True)

if __name__=='__main__':
    import sys
    prepare_access() if '--prepare-access' in sys.argv else main()
