import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import network_access,setup_config
class NetworkTests(unittest.TestCase):
 def test_migrate_preserves_port_retires_proxies(self):
  for port in (80,8000,8080):
   with self.subTest(port=port),tempfile.TemporaryDirectory() as d:
    root=Path(d);etc=root/'etc/mmod';etc.mkdir(parents=True);(etc/'listen.env').write_text('MMOD_BIND=192.0.2.5\nMMOD_PORT='+str(port)+'\n')
    units=root/'etc/systemd/system';units.mkdir(parents=True)
    (units/'mmod-network.socket').write_text('old socket');(units/'mmod-network.service').write_text('old proxy')
    with patch.object(network_access.subprocess,'run') as run:network_access.migrate(root)
    self.assertEqual((etc/'listen.env').read_text(),'MMOD_BIND=0.0.0.0\nMMOD_PORT='+str(port)+'\n')
    commands=[x.args[0] for x in run.call_args_list]
    self.assertLess(commands.index(['systemctl','disable','--now','mmod-network.socket']),commands.index(['systemctl','restart','mmod']))
    self.assertFalse(any('enable' in x for x in commands))
 def test_no_interfaces_needed(self):
  with tempfile.TemporaryDirectory() as d,patch.object(setup_config.subprocess,'check_output',side_effect=AssertionError('must not enumerate addresses')):
   plan=setup_config.make_plan(setup_config.parser().parse_args([]),Path(d));self.assertEqual(plan['bind'],'0.0.0.0');setup_config.check_interface(plan)
