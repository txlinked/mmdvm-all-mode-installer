import datetime
import unittest
from fusion_activity import snapshot
from idle_links import due

class FusionRFTests(unittest.TestCase):
 def test_rf_start_end_and_network_exemption(self):
  now=datetime.datetime(2026,10,7,0,0,10,tzinfo=datetime.timezone.utc).timestamp()
  lines=['M: 2026-10-07 00:00:01.000 YSF, received RF header from     N3DMC to DG-ID 0',
         'M: 2026-10-07 00:00:04.000 YSF, received RF end of transmission from     N3DMC to DG-ID 0, 3.0 seconds']
  state=snapshot(lines,now);self.assertFalse(state['active']);self.assertEqual(state['last_rf'],now-6)
  network='M: 2026-10-07 00:00:09.000 YSF, received network end of transmission from N3DMC to DG-ID 0 at N3DMC, 2.0 seconds'
  self.assertEqual(snapshot([network],now,state)['last_rf'],state['last_rf'])
  self.assertTrue(snapshot(lines[:1],now)['active'])
 def test_native_timer_uses_only_fusion_rf_and_requires_source(self):
  links={'slots':[{'slot':None,'links':[{'kind':'gateway','mode':'ysf','family':'FCS','destination':'FCS00334'}]}]}
  for supported,last_rf,active,count in [(False,100,False,0),(True,100,False,1),(True,950,False,0),(True,100,True,0)]:
   monitor={'native_ysf':{'supported':supported,'last_rf':last_rf,'active':active},'activity':[{'source':'RF','slot':1,'ended':999}]}
   jobs,_=due(links,monitor,{'2|FCS|FCS00334':100},1000,limit=300)
   self.assertEqual(len(jobs),count)
