import unittest,json
import configuration as c
class ConfigurationTests(unittest.TestCase):
 def base(self):
  return {'station':json.dumps({'site':'Test','network':'MMOD','description':'test'}),'host':'[General]\nCallsign=N3DMC\nId=3202139\nDuplex=1\n[Modem]\nTXFrequency=441325000\nRXFrequency=446325000\nRXInvert=0\n[DMR]\nColorCode=9\n[System Fusion]\nEnable=0\n','dmr':'[General]\nId=3202139\n[Info]\nTXFrequency=441325000\nRXFrequency=446325000\nColorCode=9\n[DMR Network 2]\nEnabled=1\nName=C-Bridge2\nPassword=keep-this-secret\nTGRewrite0=2,3148,2,3148,1\nPassAllPC=1\nPassAllPC=2\n'}
 def test_frequency_and_identity_sync_preserve_routes_and_secret(self):
  b=self.base();d=c.plan(b,{'host.Modem.TXFrequency':'441.35','host.General.Id':'3202140'})
  self.assertIn('TXFrequency=441350000',d['host']);self.assertIn('TXFrequency=441350000',d['dmr']);self.assertIn('Id=3202140',d['dmr'])
  self.assertIn('Password=keep-this-secret',d['dmr']);self.assertIn('TGRewrite0=2,3148,2,3148,1',d['dmr']);self.assertIn('PassAllPC=1\nPassAllPC=2',d['dmr'])
 def test_secret_redacted_and_blank_keeps(self):
  b=self.base();fields=[f for g in c.schema(b) for f in g['fields']];f=next(f for f in fields if f['kind']=='secret');self.assertEqual(f['value'],'');self.assertTrue(f['configured']);self.assertEqual(c.plan(b,{f['id']:''}),b)
 def test_reject_invalid_route_and_injection(self):
  for changes in [{'dmr.DMR Network 2.tgrewrite0':'2,3148,3,3148,1'},{'host.General.Callsign':'N3DMC\nDuplex=0'}]:
   with self.assertRaises(ValueError):c.plan(self.base(),changes)
 def test_duplicate_edited_key_rejected(self):
  with self.assertRaises(ValueError):c.replace_ini('[DMR]\nColorCode=9\nColorCode=1\n','DMR','ColorCode','2')
if __name__=='__main__':unittest.main()
