import unittest
from idle_links import due
class TimerChoiceTests(unittest.TestCase):
 def sample(self):
  return {'slots':[{'slot':2,'links':[{'kind':'gateway','mode':'dmr2ysf','family':'FCS','destination':'FCS00334'}]}]}
 def test_selected_minutes_and_disable(self):
  key='2|FCS|FCS00334';links=self.sample()
  for policy,count in [({'minutes':5},1),({'minutes':30},0),({'enabled':False},0),({'static':True},0)]:
   jobs,_=due(links,{}, {key:100},1000,policies={key:policy});self.assertEqual(len(jobs),count)
 def test_rf_only_resets(self):
  key='2|FCS|FCS00334'
  for source,count in [('network',1),('RF',0)]:
   jobs,_=due(self.sample(),{'activity':[{'source':source,'slot':2,'ended':950}]},{key:100},1000,policies={key:{'minutes':5}});self.assertEqual(len(jobs),count)
 def test_brandmeister_whole_slot_disabled_and_static_safe(self):
  links={'slots':[{'slot':1,'clear_dynamic':True,'links':[{'kind':'dynamic','mode':'dmr','family':'BrandMeister','destination':'91'},{'kind':'static','mode':'dmr','family':'BrandMeister','destination':'93'}]}]}
  for enabled,count in [(True,1),(False,0)]:
   jobs,_=due(links,{}, {'1|BrandMeister|91':100},1000,policies={'1|BrandMeister|*':{'minutes':5,'enabled':enabled}});self.assertEqual(len(jobs),count)
 def test_changed_setting_starts_new_interval(self):
  jobs,_=due(self.sample(),{}, {'2|FCS|FCS00334':100},1000,policies={'2|FCS|FCS00334':{'minutes':5,'updated':999}});self.assertFalse(jobs)
