"""MMOD station configuration: allowlisted INI edits in a separate root worker."""
import configparser
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import pwd
import subprocess
import time
import uuid
from decimal import Decimal, InvalidOperation

STATE = Path('/var/lib/mmod/state')
LIVE = Path('/run/mmod')
SETTINGS = Path('/etc/mmod')
BACKUPS = Path('/var/backups/mmod-configuration')


def read_json(path, fallback=None):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return {} if fallback is None else fallback


def atomic(path, data, mode=0o640):
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        fd = os.open(temp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, mode)
        with os.fdopen(fd, 'w') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def parse(text):
    # DMRGateway legitimately repeats routing directives (PassAllTG, etc.).
    # Those lines are preserved verbatim; replace_ini rejects duplicate edited keys.
    p = configparser.ConfigParser(interpolation=None, strict=False, inline_comment_prefixes=('#', ';'))
    p.read_string(text)
    return p


def files():
    c = read_json(SETTINGS / 'config.json')
    profile = read_json(SETTINGS / 'control-profile.json')
    out = {'station': (SETTINGS / 'config.json', '')}
    if c.get('mmdvm_ini') and Path(c['mmdvm_ini']).is_file():
        out['host'] = (Path(c['mmdvm_ini']), c.get('host_service') or 'mmdvmhost.service')
    for key in ('dmr', 'ysf'):
        item = profile.get(key) or {}
        if item.get('ini') and Path(item['ini']).is_file() and re.fullmatch(r'[a-zA-Z0-9_.@-]+\.service', item.get('service', '')):
            out[key] = (Path(item['ini']), item['service'])
    # Paths come from root-owned local dashboard profiles; legacy radio INIs may belong to the repeater service account.
    trusted_uids={0}
    try: trusted_uids.add(pwd.getpwnam('repeater').pw_uid)
    except KeyError: pass
    for key, (path, service) in out.items():
        st = path.lstat()
        if not stat.S_ISREG(st.st_mode) or st.st_uid not in trusted_uids or st.st_mode & 0o002:
            raise ValueError('Configuration file must belong to root/repeater and not be world-writable: ' + key)
        if st.st_size > 262144:
            raise ValueError('Configuration file too large: ' + key)
    return out


def field(id, file, section, key, label, kind='text', low=None, high=None, choices=None):
    return dict(id=id, file=file, section=section, key=key, label=label, kind=kind, low=low, high=high, choices=choices)


def schema(contents):
    groups = []
    parsed = {k: parse(v) for k, v in contents.items() if k != 'station'}
    station = json.loads(contents['station'])
    def group(title, entries):
        result = []
        for f in entries:
            if f['file'] == 'station':
                value = station.get(f['key'], '')
            else:
                p = parsed.get(f['file'])
                if p is None:
                    continue
                if not p.has_option(f['section'], f['key']):
                    if f['id'] != 'host.NXDN.Id' or not p.has_section('NXDN'):
                        continue
                    value = ''
                else:
                    value = p.get(f['section'], f['key'])
            if f['kind'] == 'frequency':
                value = str(Decimal(value) / 1000000)
            f['value'] = '' if f['kind'] == 'secret' else str(value)
            if f['kind'] == 'secret':
                f['configured'] = bool(value)
            result.append(f)
        if result:
            groups.append(dict(title=title, fields=result))
    def h(section, key, label, kind='text', low=None, high=None):
        return field('host.' + section + '.' + key, 'host', section, key, label, kind, low, high)
    group('Station', [field('station.site', 'station', '', 'site', 'Dashboard name'),
        field('station.network', 'station', '', 'network', 'Organization / network'),
        field('station.description', 'station', '', 'description', 'Dashboard description'),
        h('General', 'Callsign', 'Station callsign', 'callsign'), h('General', 'Id', 'DMR ID', 'int', 1, 16777215),
        h('NXDN', 'Id', 'NXDN ID (separate from DMR)', 'int', 1, 65519),
        h('Info', 'Location', 'Location'), h('Info', 'Description', 'Radio description'), h('Info', 'URL', 'Website'),
        h('Info', 'Latitude', 'Latitude', 'decimal', -90, 90), h('Info', 'Longitude', 'Longitude', 'decimal', -180, 180),
        h('Info', 'Power', 'Power (watts)', 'int', 0, 1500), h('Info', 'Height', 'Antenna height (metres)', 'int', 0, 10000)])
    entries = [h('General', 'Duplex', 'Duplex repeater', 'bool'), h('DMR', 'ColorCode', 'DMR color code', 'int', 0, 15)]
    # Some host versions use Modem frequencies, others Info. Keep duplicate values in sync on save.
    for direction, label in [('TX', 'Transmit / downlink (MHz)'), ('RX', 'Receive / uplink (MHz)')]:
        section = 'Modem' if parsed.get('host') and parsed['host'].has_option('Modem', direction + 'Frequency') else 'Info'
        entries.append(h(section, direction + 'Frequency', label, 'frequency', 1, 1300))
    entries += [h('Modem', 'Protocol', 'Modem connection protocol'), h('Modem', 'UARTPort', 'Modem serial port', 'device'), h('Modem', 'Port', 'Modem serial port', 'device'), h('Modem', 'UARTSpeed', 'Modem baud rate', 'int', 1200, 1000000), h('Modem', 'RXOffset', 'RX offset (Hz)', 'int', -100000, 100000), h('Modem', 'TXOffset', 'TX offset (Hz)', 'int', -100000, 100000), h('Modem', 'DMRDelay', 'DMR delay', 'int', 0, 1000), h('Modem', 'RXLevel', 'RX level', 'decimal', 0, 100), h('Modem', 'TXLevel', 'TX level', 'decimal', 0, 100),
        h('Modem', 'RXInvert', 'Invert RX', 'bool'), h('Modem', 'TXInvert', 'Invert TX', 'bool'),
        h('Modem', 'PTTInvert', 'Invert PTT', 'bool'), h('Modem', 'TXDelay', 'TX delay (ms)', 'int', 0, 1000),
        h('General', 'Timeout', 'Transmit timeout (seconds)', 'int', 15, 600)]
    group('Radio / modem', entries)
    group('Modes', [h(s, 'Enable', label, 'bool') for s, label in [('DMR', 'DMR'), ('System Fusion', 'Yaesu System Fusion'), ('D-Star', 'D-Star'), ('P25', 'P25'), ('NXDN', 'NXDN'), ('M17', 'M17'), ('POCSAG', 'POCSAG paging'), ('FM', 'Analog FM')]])
    group('FM / AllStar preparation', [h('FM', 'CTCSSFrequency', 'CTCSS / PL tone (Hz)', 'decimal', 60, 260),
        h('FM', 'CTCSSLevel', 'Transmit tone level', 'int', 0, 100),
        h('FM', 'AccessMode', 'Access: 0 carrier, 1 tone, 2 carrier + tone', 'int', 0, 2)])
    for network in ('DMR Network', 'System Fusion Network', 'D-Star Network', 'P25 Network', 'NXDN Network', 'M17 Network', 'POCSAG Network', 'FM Network'):
        group('Host · ' + network, [h(network, key, label, kind, low, high) for key, label, kind, low, high in [
            ('Enable', 'Network enabled', 'bool', None, None), ('Slot1', 'Timeslot 1 enabled', 'bool', None, None), ('Slot2', 'Timeslot 2 enabled', 'bool', None, None), ('LocalAddress', 'Local address', 'address', None, None),
            ('LocalPort', 'Local UDP port', 'int', 1024, 65535), ('GatewayAddress', 'Gateway address', 'address', None, None),
            ('GatewayPort', 'Gateway UDP port', 'int', 1, 65535), ('RemoteAddress', 'Remote address', 'address', None, None),
            ('RemotePort', 'Remote UDP port', 'int', 1, 65535), ('Password', 'Network password', 'secret', None, None)]])
    for index in range(1, 6):
        section = 'DMR Network ' + str(index)
        group('DMR gateway · network ' + str(index), [field('dmr.' + section + '.' + k, 'dmr', section, k, label, kind, lo, hi)
            for k, label, kind, lo, hi in [('Enabled', 'Enabled', 'bool', None, None), ('Name', 'Network name', 'text', None, None),
                ('Address', 'Server address', 'address', None, None), ('Port', 'Server port', 'int', 1, 65535),
                ('Local', 'Local port (0 = automatic)', 'int', 0, 65535), ('Id', 'DMR ID', 'int', 1, 16777215),
                ('Password', 'Password', 'secret', None, None), ('Options', 'Network options', 'text', None, None)]])
    dmr_config = parsed.get('dmr')
    if dmr_config:
        for section in dmr_config.sections():
            if not re.fullmatch(r'DMR Network [1-5]', section): continue
            routes = [field('dmr.'+section+'.'+key, 'dmr', section, key, key, 'route') for key in dmr_config[section] if re.fullmatch(r'tgrewrite[0-9]+', key, re.I) and dmr_config[section][key].strip()]
            group('DMR routing · '+section, routes)
    for section, keys in [('General', [('Callsign','Callsign','callsign'),('RptAddress','Radio address','address'),('RptPort','Radio UDP port','port'),('LocalAddress','Local address','address'),('LocalPort','Gateway UDP port','port')]),
        ('Network', [('Startup','Startup reflector / room','text'),('InactivityTimeout','Inactivity timeout (minutes)','timeout'),('Reconnect','Reconnect','bool'),('Revert','Revert to startup','bool')]),
        ('FCS Network', [('Enable','Enable FCS','bool')]), ('YSF Network', [('Enable','Enable YSF','bool')])]:
        group('YSF / FCS · ' + section, [field('ysf.' + section + '.' + k,'ysf',section,k,label,
            'int' if kind in ('port','timeout') else kind, 1 if kind=='port' else 0 if kind=='timeout' else None,
            65535 if kind=='port' else 1440 if kind=='timeout' else None) for k,label,kind in keys])
    # Promote configured conversion routes to their own selectable section.
    cross_fields = []
    dmr = parsed.get('dmr')
    supported = {'dmr2ysf': 'DMR → YSF / FCS', 'dmr2nxdn': 'DMR → NXDN', 'dmr2p25': 'DMR → P25'}
    if dmr:
        for section in dmr.sections():
            name = dmr.get(section, 'Name', fallback='').lower().replace(' ', '')
            mode = next((m for m in supported if m in name), None)
            if not mode:
                continue
            setting = 'dmr.' + section + '.Enabled'
            for g in groups:
                for f in list(g['fields']):
                    if f['id'] == setting:
                        g['fields'].remove(f)
                        f['label'] = supported[mode]
                        cross_fields.append(f)
    if cross_fields:
        groups.insert(3, dict(title='Cross modes', fields=cross_fields))
    return groups


def revision(contents):
    return hashlib.sha256(json.dumps(contents, sort_keys=True).encode()).hexdigest()


def snapshot():
    paths = files()
    contents = {key: path.read_text() for key, (path, _) in paths.items()}
    pending = read_json(SETTINGS / 'setup-pending.json')
    return contents, dict(revision=revision(contents), groups=schema(contents), updated=time.time(),
        pending_services=pending.get('services', []), modules=read_json(Path('/var/lib/mmod/modules.json')).get('modules', []),
        warnings=['Save writes configuration only. Apply restarts affected running radio services and interrupts traffic.',
            'New modes need compatible modem firmware and a configured gateway. Existing routing rules are preserved.'])


def validate_value(f, value):
    if not isinstance(value, str) or len(value) > 200 or any(ord(c) < 32 for c in value) or any(c in value for c in '\r\n#;'):
        raise ValueError('Invalid value: ' + f['label'])
    value = value.strip()
    kind = f['kind']
    if kind == 'secret' and not value:
        return None
    if kind == 'bool' and value not in ('0', '1'):
        raise ValueError('Choose on or off: ' + f['label'])
    if kind in ('int', 'decimal', 'frequency'):
        try:
            n = Decimal(value)
        except InvalidOperation:
            raise ValueError('Enter a number: ' + f['label'])
        if not n.is_finite() or not Decimal(str(f['low'])) <= n <= Decimal(str(f['high'])) or kind == 'int' and n != n.to_integral_value():
            raise ValueError('Out of range: ' + f['label'])
        if kind == 'frequency':
            if n * 1000000 != (n * 1000000).to_integral_value():
                raise ValueError('Frequency must resolve to whole Hz')
            value = str(int(n * 1000000))
    if kind == 'route':
        if not re.fullmatch(r'[12],[0-9]+,[12],[0-9]+,[0-9]+', value): raise ValueError('Route format: RF slot,TG,network slot,TG,count')
        rf,tg,net,target,count=map(int,value.split(','))
        if min(tg,target,count)<1 or max(tg+count-1,target+count-1)>16777215: raise ValueError('Talkgroup route out of range')
    if kind == 'device' and not re.fullmatch(r'/dev/[A-Za-z0-9_./:-]+',value): raise ValueError('Use a modem device under /dev')
    if kind == 'callsign':
        value = value.upper()
        if not re.fullmatch(r'[A-Z0-9/]{3,12}', value):
            raise ValueError('Invalid callsign')
    if kind == 'address' and not re.fullmatch(r'[A-Za-z0-9.:-]{1,253}', value):
        raise ValueError('Invalid host address')
    return value


def replace_ini(text, section, key, value):
    lines = text.splitlines(keepends=True)
    current = None
    count = 0
    for index, line in enumerate(lines):
        m = re.match(r'^\s*\[([^]]+)\]', line)
        if m:
            current = m[1]
        if current == section and re.match(r'^\s*' + re.escape(key) + r'\s*=', line, re.I):
            comment = re.search(r'(\s+[;#].*)', line.rstrip('\r\n'))
            lines[index] = key + '=' + value + (comment.group(1) if comment else '') + '\n'
            count += 1
    if count == 0 and section == 'NXDN' and key == 'Id':
        headers = [i for i, line in enumerate(lines) if re.match(r'^\s*\[NXDN\]\s*(?:[;#].*)?$', line.strip())]
        if len(headers) == 1:
            i = headers[0]
            if not lines[i].endswith('\n'): lines[i] += '\n'
            lines.insert(i + 1, 'Id=' + value + '\n')
            return ''.join(lines)
    if count != 1:
        raise ValueError('Configuration changed or duplicate key: ' + section + '/' + key)
    return ''.join(lines)


def plan(contents, changes):
    if not isinstance(changes, dict) or not changes or len(changes) > 150:
        raise ValueError('Select at least one change')
    fields = {f['id']: f for g in schema(contents) for f in g['fields']}
    result = dict(contents)
    for id, raw in changes.items():
        if id not in fields:
            raise ValueError('Unsupported setting')
        f = fields[id]
        value = validate_value(f, raw)
        if value is None:
            continue
        if f['file'] == 'station':
            c = json.loads(result['station']); c[f['key']] = value
            result['station'] = json.dumps(c, indent=2) + '\n'
        else:
            result[f['file']] = replace_ini(result[f['file']], f['section'], f['key'], value)
            if f['kind'] == 'frequency':
                other = 'Info' if f['section'] == 'Modem' else 'Modem'
                if parse(result['host']).has_option(other, f['key']):
                    result['host'] = replace_ini(result['host'], other, f['key'], value)
    host = parse(result.get('host', ''))
    station = json.loads(result['station'])
    for setting in changes:
        f=fields[setting]
        if f['file']=='host' and f['kind']=='frequency': station.get('display_frequencies_hz',{}).pop(f['key'],None)
        if setting=='host.DMR.ColorCode': station.pop('display_color_code',None)
    if station != json.loads(result['station']): result['station']=json.dumps(station,indent=2)+'\n'
    # Keep gateway identity and frequency metadata aligned with host edits.
    if 'dmr' in result:
        for setting,section,key in [('host.General.Id','General','Id'),('host.General.Callsign','Info','Callsign'),('host.General.Duplex','Info','Duplex'),('host.DMR.ColorCode','Info','ColorCode')]:
            if setting in changes and parse(result['dmr']).has_option(section,key):
                f=fields[setting];value=parse(result['host']).get(f['section'],f['key']);result['dmr']=replace_ini(result['dmr'],section,key,value)
        for setting in changes:
            f=fields[setting]
            if f['file']=='host' and f['kind']=='frequency' and parse(result['dmr']).has_option('Info',f['key']): result['dmr']=replace_ini(result['dmr'],'Info',f['key'],parse(result['host']).get(f['section'],f['key']))
    # Do not activate native Fusion against an active DMR2YSF route.
    if host.get('System Fusion', 'Enable', fallback='0') == '1' and 'dmr' in result:
        dmr = parse(result['dmr'])
        for s in dmr.sections():
            if 'dmr2ysf' in dmr.get(s, 'Name', fallback='').lower() and dmr.get(s, 'Enabled', fallback='0') == '1':
                raise ValueError('Disable the DMR2YSF gateway network before enabling native Fusion')
    return result


def execute(job):
    contents, info = snapshot()
    if job.get('revision') != info['revision']:
        raise ValueError('Configuration changed. Reload the page and review again.')
    paths = files()
    if job.get('action') == 'save':
        changed = plan(contents, job.get('changes'))
        keys = [k for k in contents if changed[k] != contents[k]]
        if not keys:
            return 'No changes to save.'
        backup = BACKUPS / (time.strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:8])
        backup.mkdir(parents=True, mode=0o700)
        for k in keys:
            shutil.copy2(paths[k][0], backup / (k + '.backup'))
        try:
            for k in keys:
                p = paths[k][0]
                st = p.stat()
                atomic(p, changed[k], stat.S_IMODE(st.st_mode))
                os.chown(p, st.st_uid, st.st_gid)
        except Exception:
            for k in keys:
                shutil.copy2(backup / (k + '.backup'), paths[k][0])
            raise
        previous = read_json(SETTINGS / 'setup-pending.json')
        services = sorted(set(previous.get('services', [])) | {paths[k][1] for k in keys if paths[k][1]})
        atomic(SETTINGS / 'setup-pending.json', json.dumps(dict(services=services, revision=revision(changed), backup=str(backup))), 0o600)
        return 'Saved. Backup created. ' + ('Apply when ready to restart affected services.' if services else 'Dashboard details refresh automatically.')
    if job.get('action') == 'apply':
        pending = read_json(SETTINGS / 'setup-pending.json')
        if pending.get('revision') != info['revision']:
            raise ValueError('Saved settings changed; save/review again before applying.')
        allowed = {v[1] for v in paths.values() if v[1]}
        services = pending.get('services', [])
        if any(s not in allowed for s in services):
            raise ValueError('Unexpected service in apply request')
        stopped = []
        for s in services:
            if subprocess.run(['systemctl', 'is-active', '--quiet', s]).returncode != 0:
                stopped.append(s)
                continue
            subprocess.run(['systemctl', 'restart', s], check=True, timeout=45)
            subprocess.run(['systemctl', 'is-active', '--quiet', s], check=True, timeout=5)
        # Refresh mode routing only after explicit Apply, without granting the
        # web process filesystem or systemctl access.
        from discover_controls import discover, crossmode_sources
        config = read_json(SETTINGS / 'config.json')
        profile = discover(config)
        atomic(SETTINGS / 'control-profile.json', json.dumps(profile), 0o644)
        config['crossmode_sources'] = crossmode_sources(profile)
        atomic(SETTINGS / 'config.json', json.dumps(config, indent=2) + '\n', 0o640)
        atomic(SETTINGS / 'setup-pending.json', '{}', 0o600)
        return 'Applied to running services.' + (' Left stopped: ' + ', '.join(stopped) if stopped else '')
    raise ValueError('Unknown setup action')


def worker():
    LIVE.mkdir(exist_ok=True)
    with open('/run/lock/mmod-configuration.lock', 'w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        request = STATE / 'setup-request.json'
        if request.exists():
            job = {}
            try:
                fd = os.open(request, os.O_RDONLY | os.O_NOFOLLOW)
                with os.fdopen(fd) as f:
                    text = f.read(32769)
                request.unlink()
                if len(text) > 32768:
                    raise ValueError('Request too large')
                job = json.loads(text)
                if abs(time.time() - float(job.get('created', 0))) > 120:
                    raise ValueError('Request expired; submit again')
                atomic(LIVE / 'setup-result.json', json.dumps(dict(id=job.get('id'), running=True, updated=time.time(), message='Applying configuration request…')))
                message = execute(job)
                result = dict(ok=True, message=message)
            except Exception as exc:
                request.unlink(missing_ok=True)
                # Never include values, secrets, or subprocess output in the public result.
                result = dict(ok=False, message=str(exc) if isinstance(exc, ValueError) else 'Save/apply failed. Check the configuration worker log.')
            result.update(id=job.get('id'), updated=time.time())
            atomic(LIVE / 'setup-result.json', json.dumps(result))
        try:
            _, info = snapshot()
            atomic(LIVE / 'setup.json', json.dumps(info))
        except Exception:
            atomic(LIVE / 'setup.json', json.dumps(dict(error='Unable to read station configuration. No changes made.', updated=time.time())))


if __name__ == '__main__':
    worker()
