import unittest
from idle_links import due

class FullStackTimerTests(unittest.TestCase):
 def bm(self):
  return {'slots':[{'slot':1,'clear_dynamic':True,'links':[
   {'kind':'dynamic','mode':'dmr','family':'BrandMeister','destination':'91'},
   {'kind':'dynamic','mode':'dmr','family':'BrandMeister','destination':'92'},
   {'kind':'static','mode':'dmr','family':'BrandMeister','destination':'93'}]}]}
 def test_any_rf_in_slot_resets_whole_slot(self):
  remember={'1|BrandMeister|91':100,'1|BrandMeister|92':100}
  for source,slot,count in [('RF',1,0),('network',1,1),('RF',2,1)]:
   jobs,_=due(self.bm(),{'activity':[{'source':source,'slot':slot,'target':'999','ended':950}]},remember,1000,limit=300)
   self.assertEqual(len(jobs),count)
 def test_room_policies_are_independent(self):
  rooms={'slots':[{'slot':2,'links':[{'kind':'gateway','mode':'dmr2ysf','family':'FCS','destination':room} for room in ('FCS00334','FCS00100')]}]}
  keys=['2|FCS|FCS00334','2|FCS|FCS00100']
  jobs,_=due(rooms,{},dict.fromkeys(keys,100),1000,policies={keys[0]:{'enabled':False},keys[1]:{'minutes':5}})
  self.assertEqual([j['destination'] for j in jobs],['FCS00100'])
 def test_unsupported_modes_never_expire(self):
  for mode,family,kind in [('allstar','AllStar','dynamic'),('p25','P25','gateway'),('dmr','CBridge','dynamic')]:
   key='2|'+family+'|91'
   jobs,_=due({'slots':[{'slot':2,'clear_dynamic':True,'links':[{'kind':kind,'mode':mode,'family':family,'destination':'91'}]}]}, {}, {key:100},1000,limit=300)
   self.assertFalse(jobs)
 def test_static_and_disabled_slot_exempt(self):
  for policy in ({'enabled':False},{'static':True}):
   jobs,_=due(self.bm(),{}, {'1|BrandMeister|91':100,'1|BrandMeister|92':100},1000,limit=300,policies={'1|BrandMeister|*':policy})
   self.assertFalse(jobs)
