"""Native Fusion RF activity from the pinned MMDVM-Host console log."""
import datetime
import re

START=re.compile(r'YSF, received RF (?:header|late entry) from\s+(\S+)\s+to DG-ID (\d+)')
END=re.compile(r'YSF, (?:received RF end of transmission|transmission lost) from\s+(\S+)\s+to (?:DG-ID )?([^,]+), ([\d.]+) seconds')

def snapshot(lines,now,previous=None):
    state={**(previous or {}),'updated':now}
    state.setdefault('last_rf',0);state.setdefault('active',False)
    for line in lines:
        try:stamp=datetime.datetime.strptime(line[3:26],'%Y-%m-%d %H:%M:%S.%f').replace(tzinfo=datetime.timezone.utc).timestamp()
        except ValueError:continue
        if stamp>now+5 or stamp<state['last_rf']:continue
        match=START.search(line)
        if match:
            state.update(last_rf=stamp,active=True,caller=match[1],target=match[2])
        elif END.search(line) or (state['active'] and ('YSF, RF user has timed out' in line or 'Mode set to Idle' in line)):
            state.update(last_rf=stamp,active=False)
    if state['active'] and now-state['last_rf']>180:state['active']=False
    return state
