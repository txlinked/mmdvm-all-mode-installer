'use strict';
(()=>{
 const panel=node('article',undefined,'panel');panel.hidden=true;panel.append(node('h3','Dashboard updates'));
 panel.append(node('p','Updates come from the stable release selected on txlinked/mmod GitHub. Saved settings and credentials are preserved. Automatic updates default to off. Scheduled time uses this repeater computer’s local clock.','caption'));
 const info=node('p'),message=node('p'),check=node('button','Check now'),install=node('button','Update now','primary'),changes=node('a','View changes');changes.target='_blank';changes.rel='noopener noreferrer';
 const auto=document.createElement('input');auto.type='checkbox';const label=node('label',' Automatic updates ');label.prepend(auto);
 const schedule=document.createElement('input');schedule.type='time';schedule.value='03:00';const timeLabel=node('label',' Update time ');timeLabel.append(schedule);const save=node('button','Save update settings');
 panel.append(info,check,changes,install,label,timeLabel,save,message);$('admin-content').append(panel);
 const notice=node('div',undefined,'panel');notice.hidden=true;const noticeText=node('span'),open=node('button','Update options'),later=node('button','Later');notice.append(noticeText,open,later);$('overview').prepend(notice);
 let dismissed='',current='',busy=false,loaded=false;
 later.onclick=()=>{dismissed=current;notice.hidden=true;};open.onclick=()=>{document.querySelector('[data-view="admin"]').click();panel.scrollIntoView({behavior:'smooth'});};
 async function action(action,extra={}){try{message.textContent=(await api('updates',{method:'POST',body:JSON.stringify({action,...extra})})).message;await poll();}catch(e){message.textContent=e.message;}}
 check.onclick=()=>action('check');save.onclick=()=>action('settings',{enabled:auto.checked,schedule:schedule.value});
 install.onclick=()=>{if(confirm('Update MMOD from GitHub? Dashboard access will briefly pause. Saved configuration and passwords are preserved.'))action('install');};
 async function poll(){if(busy)return;const admin=!!csrf&&window.v2Identity?.role==='admin';panel.hidden=!admin;if(!admin){notice.hidden=true;loaded=false;dismissed='';return;}busy=true;
 try{const d=await api('updates');current=d.version||'';info.textContent='Installed V'+d.installed+' · Stable '+(d.version?'V'+d.version:'not checked');message.textContent=d.error||d.message||'';
 changes.href=d.commit?'https://github.com/txlinked/mmod/blob/'+d.commit+'/BUILDLOG.md':'https://github.com/txlinked/mmod';
 install.disabled=!d.available||d.running||d.pending;check.disabled=d.running||d.pending;
 if(!loaded){auto.checked=d.enabled;schedule.value=d.schedule;loaded=true;}
 notice.hidden=!(d.available&&dismissed!==current);noticeText.textContent='MMOD V'+current+' is available. ';
 }catch(e){message.textContent='Dashboard reconnecting: '+e.message;}finally{busy=false;}}
 setInterval(poll,5000);poll();
})();
