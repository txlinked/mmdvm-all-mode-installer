"""Administrator update API; execution belongs to the separate root timer."""
import json,re,secrets,time
from pathlib import Path
from fastapi import HTTPException,Request
from pydantic import BaseModel,Field
import accounts
class UpdateRequest(BaseModel):
    action:str
    enabled:bool=Field(default=False,strict=True)
    schedule:str='03:00'
def settings(state):
    try:d=json.loads((state/'updates-settings.json').read_text())
    except (OSError,ValueError):d={}
    return {'enabled':d.get('enabled') is True,'schedule':d.get('schedule','03:00')}
def atomic(path,data):
    temp=path.with_name(path.name+'.'+secrets.token_hex(8))
    try:temp.write_text(json.dumps(data));temp.chmod(0o600);temp.replace(path)
    finally:temp.unlink(missing_ok=True)
def install_routes(app,state):
    @app.get('/api/updates')
    def status(request:Request):
        accounts.require(state,request,admin=True)
        try:d=json.loads(Path('/var/lib/mmod-updates/status.json').read_text())
        except (OSError,ValueError):d={'message':'Waiting for first GitHub check.'}
        d.update(settings(state));d['installed']=Path('/opt/mmod/VERSION').read_text().strip()
        d['pending']=(state/'updates-request.json').exists()
        return d
    @app.post('/api/updates')
    def change(body:UpdateRequest,request:Request):
        actor=accounts.require(state,request,write=True,admin=True)
        if body.action=='settings':
            if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',body.schedule):raise HTTPException(400,'Use HH:MM local system time')
            atomic(state/'updates-settings.json',{'enabled':body.enabled,'schedule':body.schedule})
            message='Automatic updates '+('enabled at '+body.schedule if body.enabled else 'disabled')
        elif body.action in ('check','install'):
            if (state/'updates-request.json').exists():raise HTTPException(409,'An update request is already pending')
            atomic(state/'updates-request.json',{'action':body.action,'created':time.time()})
            message='Request queued; the update worker checks within one minute.'
        else:raise HTTPException(400,'Unsupported update action')
        with accounts.connect(state) as con:accounts.record(con,actor['username'],'dashboard update',body.action)
        return {'message':message}
